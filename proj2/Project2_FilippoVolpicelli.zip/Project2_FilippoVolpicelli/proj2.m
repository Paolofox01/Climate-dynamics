function dydt = ode1(t, y)
   dydt = [4*y(1) - y(2); 2*y(1) + y(2)];
end



[t,y] = ode45(@ode1,[0 1],[2; 3]);



function sol = sol1(t, c)
   sol = [c(1).*exp(3.*t) + c(2).*exp(2.*t); c(1).*exp(3.*t) + 2.*c(2).*exp(2.*t)];
end

temp = linspace(0,1,45);
c=[1;1];

sol = sol1(temp, c);

figure;
subplot(1, 2, 1);
hold on 

plot( y(:, 1), y(:,2), "r", 'LineWidth', 2)
plot(sol(1,:), sol(2,:), "b")
xlabel("x")
ylabel("y")

hold off

subplot(1, 2, 2);
hold on 

plot3(t, y(:, 1), y(:,2), "r", 'LineWidth', 2)
plot3(temp, sol(1,:), sol(2,:), "b")
xlabel("t")
ylabel("x")
zlabel("y")

hold off

%% stream2
[x1, x2] = meshgrid(-1:0.05:1, -1:0.05:1);

u = 4*x1 - x2;  
v = 2*x1 + x2; 

[startX, startY] = meshgrid(-1:0.2:1, -1:0.2:1);

verts = stream2(x1, x2, u, v, startX, startY);

hold on
streamline(verts)

xlabel('x')
ylabel('y')
axis equal
grid on
hold off

%% second system 

function dydt = ode2(t, y)
   dydt = [3*y(1) - 2*y(2); 2*y(1) + 3*y(2)];
end



[t,y] = ode45(@ode2,[0 1],[1; 1]);



function sol = sol2(t, c)
   sol = [c(1).*exp(3.*t).*(-sin(2.*t)) + c(2).*exp(3.*t).*(cos(2.*t)); c(1).*exp(3.*t).*(cos(2.*t)) + c(2).*exp(3.*t).*(sin(2.*t))];
end

temp = linspace(0,1,45);
c=[1;1];

sol = sol2(temp, c);


figure;
subplot(1, 2, 1);
hold on 

plot( y(:, 1), y(:,2), "r", 'LineWidth', 2)
plot(sol(1,:), sol(2,:), "b")
xlabel("x")
ylabel("y")

hold off

subplot(1, 2, 2);
hold on 

plot3(t, y(:, 1), y(:,2), "r", 'LineWidth', 2)
plot3(temp, sol(1,:), sol(2,:), "b")
xlabel("t")
ylabel("x")
zlabel("y")

hold off

%% stream2
[x1, x2] = meshgrid(-1:0.05:1, -1:0.05:1);


u = 3*x1 - 2*x2;  
v = 2*x1 + 3*x2; 


[startX, startY] = meshgrid(-1:0.2:1, -1:0.2:1);  

verts = stream2(x1, x2, u, v, startX, startY);

hold on

streamline(verts)

xlabel('x')
ylabel('y')
axis equal
grid on
hold off

%% third system 

function dydt = ode3(t, y)
   dydt = [y(1) + y(2); -1*y(1) + 3*y(2)];
end

[t,y] = ode45(@ode3,[0 1],[0; 1]);



function sol = sol3(t, c)
   sol = [c(1).*exp(2.*t)-c(2).*exp(2.*t) + c(2).*t.*exp(2.*t); c(1).*exp(2.*t) + t.*c(2).*exp(2.*t)];
end

temp = linspace(0,1,45);
c=[1;1];

sol = sol3(temp, c);


figure;
subplot(1, 2, 1);
hold on 

plot( y(:, 1), y(:,2), "r", 'LineWidth', 2)
plot(sol(1,:), sol(2,:), "b")
xlabel("x")
ylabel("y")

hold off

subplot(1, 2, 2);
hold on 

plot3(t, y(:, 1), y(:,2), "r", 'LineWidth', 2)
plot3(temp, sol(1,:), sol(2,:), "b")
xlabel("t")
ylabel("x")
zlabel("y")

hold off
%% stream2
[x1, x2] = meshgrid(-1:0.05:1, -1:0.05:1);

u = x1 + x2;  
v = -x1 + 3*x2; 

[startX, startY] = meshgrid(-1:0.2:1, -1:0.2:1); 

verts = stream2(x1, x2, u, v, startX, startY);
hold on

streamline(verts)

xlabel('x')
ylabel('y')
axis equal
grid on
hold off

%% es 2

function dydt = LVsys(t, y)
   dydt = [y(1) - y(1).*y(2) - (y(1).^2)/2; -y(2) + y(1).*y(2) - (y(2).^2)/2];
end

x = linspace(0,3);
y = linspace(0,1);
[X,Y] = meshgrid(x,y);
Z1 = X - X.*Y - (X.^2)/2;
Z2 = -Y + X.*Y - (Y.^2)/2;
hold on
contour(X,Y,Z1,[0 0])

contour(X, Y, Z2,[0 0])

xlabel("x")
ylabel("y")

hold off


%% radice
x=1.18;
y=0.404;

n = 1000;

for i = 1:n
    f1 = x -x*y-x^2/2;
    f2 = -y + x*y-y^2/2;

    J = [1-y-x, -x;y, -1+x - y];
    delta = -J\[f1; f2];

    x = x + delta(1);
    y = y + delta(2);
end

disp([x, y]);

%%
x = 1.2;
y=0.4;

disp([1 - y - x, -x; y, -1 + x - y])
eig([1 - y - x, -x; y, -1 + x - y])

%% es 2 ver 2

function dydt = LVsys2(t, y)
   dydt = [y(1) - y(1).*y(2); -2.*y(2) + y(1).*y(2)];
end

x = linspace(0,5);
y = linspace(0,5);
[X,Y] = meshgrid(x,y);
Z1 = X - X.*Y;
Z2 = -2*Y + X.*Y;
hold on
contour(X,Y,Z1,[0 0])

contour(X, Y, Z2,[0 0])

xlabel("x")
ylabel("y")

hold off

%% radice% Initial guess
x = 2.02;
y = 1.06;

n = 100;

for i = 1:n
   
    f1 = x - x*y;     
    f2 = -2*y + x*y;     
    J = [1 - y, -x; y,-2 + x];

    delta = -J\[f1; f2];

    x = x + delta(1);
    y = y + delta(2);
end

disp([x, y]);

%%

x = 2;
y= 1;

disp([1 - y, -x;y,     -2 + x]);
eig([1 - y, -x;y,     -2 + x])


%% Probelam 2

del = 1/6;
lam = 0.2;
R=2;

[x1, x2] = meshgrid(0:0.025:0.75, 0:0.025:1);

f=(R.*x1 - x2)./lam;

u = del*(1-x1) - abs(f).*x1; 
v = (1-x2) - abs(f).*x2;  

[startX, startY] = meshgrid(0:0.075:0.75, 0:0.1:1); 
verts = stream2(x1, x2, u, v, startX, startY);

hold on

streamline(verts)

xlabel('x')
ylabel('y')
axis equal
grid on
hold off

%%

del = 1/6;
lam = 0.2;
R=2;

x = linspace(0,0.75);
y = linspace(0,1);
[X,Y] = meshgrid(x,y);

f=(R.*X - Y)./lam;

Z1 = del*(1-X) - abs(f).*X;
Z2 = (1-Y) - abs(f).*Y; 

hold on
contour(X,Y,Z1,[0 0], "b")

contour(X, Y, Z2,[0 0], "r")


hold off

%% radice
x=0.129;
y=0.485;

del = 1/6;
lam = 0.2;
R=2;

n = 1000;


for i = 1:n
    f = (R*x - y) / lam;
    
    F1 = del*(1-x) - abs(f)*x;
    F2 = (1 - y) - abs(f)*y;

    J = [ -del - abs(f) - (x*R/lam) * sign(f),  x/lam * sign(f);
          -y*R/lam * sign(f),  -1 - abs(f) + (y/lam) * sign(f) ];
    
    d = -J \ [F1; F2];
    
    x = x + d(1);
    y = y + d(2);
    
  
end

% Display results
disp([x , y]) 
a1 = x;
b1 = y;

%% 2

x=0.356;
y=0.778;

del = 1/6;
lam = 0.2;
R=2;


n = 1000;

for i = 1:n
    f = (R*x - y) / lam;
    
    F1 = del*(1-x) - abs(f)*x;
    F2 = (1 - y) - abs(f)*y;

    J = [ -del - abs(f) - (x*R/lam) * sign(f),  x/lam * sign(f);
          -y*R/lam * sign(f),  -1 - abs(f) + (y/lam) * sign(f) ];
    
    d = -J \ [F1; F2]; 
    
    x = x + d(1);
    y = y + d(2);
    
end

disp([x , y]) 

a2 = x;
b2 = y;


%% 3

x=0.432;
y=0.828;

del = 1/6;
lam = 0.2;
R=2;


n = 10000;
tol = 1e-10;

for i = 1:n
    f = (R*x - y) / lam;
    
    F1 = del*(1-x) - abs(f)*x;
    F2 = (1 - y) - abs(f)*y;

    J = [ -del - abs(f) - (x*R/lam) * sign(f),  x/lam * sign(f);
          -y*R/lam * sign(f),  -1 - abs(f) + (y/lam) * sign(f) ];
    
    d = -J \ [F1; F2]; 
    
    x = x + d(1);
    y = y + d(2);
    
end

disp([x , y]) 

a3 = x;
b3 = y;


%% 1

x=a1;
y=b1;

f = (R*x-y)/lam;


mattt = [-del - abs(f) - (x*R/lam) * sign(f),  x/lam * sign(f);
    -y*R/lam * sign(f),  -1 - abs(f) + (y/lam) * sign(f)] ;

disp(mattt)
eig(mattt)

%% 2


x=a2;
y=b2;

f = (R*x-y)/lam;


mattt = [-del - abs(f) - (x*R/lam) * sign(f),  x/lam * sign(f);
    -y*R/lam * sign(f),  -1 - abs(f) + (y/lam) * sign(f)] ;

disp(mattt)
eig(mattt)


%% 3
x=a3;
y=b3;

f = (R*x-y)/lam;


mattt = [-del - abs(f) - (x*R/lam) * sign(f),  x/lam * sign(f);
    -y*R/lam * sign(f),  -1 - abs(f) + (y/lam) * sign(f)] ;

disp(mattt)
eig(mattt)


%%

eps = 1e-9;



function stom = stomf(t, para)
    del = 1/6;
    lam = 0.2;
    R=2;
    X=para(1);
    Y=para(2);
    f=(R.*X - Y)./lam;
    
    stom = [del*(1-X) - abs(f).*X; (1-Y) - abs(f).*Y]; 
end

[~,y1] = ode45(@stomf,[0 -10],[a2; b2] + eps*double(V(:,2)));
[~,y2] = ode45(@stomf,[0 -10],[a2; b2] - eps*double(V(:,2)));
[~,y3] = ode45(@stomf,[0 100],[a2; b2] + eps*double(V(:,1)));
[~,y4] = ode45(@stomf,[0 100],[a2; b2] - eps*double(V(:,1)));



subplot(1,2,1)
hold on 
plot(y1(:,1), y1(:,2))
plot(y2(:,1), y2(:,2))
plot(y3(:,1), y3(:,2))
plot(y4(:,1), y4(:,2))
% xlim([0 2])
% ylim([0 2])
xlabel("x")
ylabel("y")
hold off


subplot(1,2,2)
hold on
plot(y1(:,1), y1(:,2))
plot(y2(:,1), y2(:,2))
plot(y3(:,1), y3(:,2))
plot(y4(:,1), y4(:,2))
xlim([0 2])
ylim([0 2])
xlabel("x")
ylabel("y")

hold off

disp([y1(end, :), y2(end, :)])




%%

function dcds = continuation_rhs_fixed(para)
    lambda = para(1);
    x = para(2);
    y = para(3);

    R = 2;
    del = 1/6;
    f = (R * x - y) / lambda;
    absf = abs(f);
    sgnf = sign(f);

    df_dlambda = sgnf * (R*x - y) * x / lambda^2;
    df_dx = -del - absf - sgnf*R*x / lambda;
    df_dy = sgnf*x / lambda;
    u = [df_dlambda; df_dx; df_dy];

    dg_dlambda = sgnf * (R*x - y) * y / lambda^2;
    dg_dx = -y * sgnf * R / lambda;
    dg_dy = -1 - absf + y * sgnf / lambda;
    v = [dg_dlambda; dg_dx; dg_dy];

    tangent = cross(u, v);
    dcds = tangent / norm(tangent);
end

lambda0 = 0.2;

s = linspace(0, 0.5, 1000);

[~, csol] = ode45(@(s, c) continuation_rhs_fixed(c), s, [lambda0, a1, b1]);
[~, csol2] = ode45(@(s, c) continuation_rhs_fixed(c), s, [lambda0, a2, b2]);
[~, csol3] = ode45(@(s, c) continuation_rhs_fixed(c), s, [lambda0, a3, b3]);

p = linspace(0, -0.5, 1000);

[~, psol] = ode45(@(s, c) continuation_rhs_fixed(c), p, [lambda0, a1, b1]);
[~, psol2] = ode45(@(s, c) continuation_rhs_fixed(c), p, [lambda0, a2, b2]);
[~, psol3] = ode45(@(s, c) continuation_rhs_fixed(c), p, [lambda0, a3, b3]);

subplot(1,2,1)
hold on
plot(csol(:,1), csol(:,2), 'LineWidth', 1, 'Color','k')
plot(csol2(:,1), csol2(:,2), 'LineWidth', 1, 'Color','k')
plot(csol3(:,1), csol3(:,2), 'LineWidth', 1, 'Color','k')
plot(psol(:,1), psol(:,2), 'LineWidth', 1, 'Color','k')
plot(psol2(:,1), psol2(:,2), 'LineWidth', 1, 'Color','k')
plot(psol3(:,1), psol3(:,2), 'LineWidth', 1, 'Color','k')
plot(lambda0, a1, 'r*')
plot(lambda0, a2, 'r*')
plot(lambda0, a3, 'r*')
xlabel('\lambda')
ylabel('x')

grid on
hold off
subplot(1,2,2)
hold on
plot(csol(:,1), csol(:,3), 'LineWidth', 1, 'Color','k')
plot(csol2(:,1), csol2(:,3), 'LineWidth', 1, 'Color','k')
plot(csol3(:,1), csol3(:,3), 'LineWidth', 1, 'Color','k')
plot(psol(:,1), psol(:,3), 'LineWidth', 1, 'Color','k')
plot(psol2(:,1), psol2(:,3), 'LineWidth', 1, 'Color','k')
plot(psol3(:,1), psol3(:,3), 'LineWidth', 1, 'Color','k')
plot(lambda0, b1, 'r*')
plot(lambda0, b2, 'r*')
plot(lambda0, b3, 'r*')
xlabel('\lambda')
ylabel('y')

grid on
hold off

%%

[lamc, id] = max(psol2(:,1));

hyp = psol2(id,2:3)

2*hyp(1)- hyp(2)
%%
syms x y u v;

h(x,y) = (1-x)/6 + (2*x-y)*x/lamc;

g(x,y) =  (1-y) + (2*x-y)*y/lamc;

d1 = coeffs(vpa(expand(h(u+hyp(1), v+hyp(2)))));

d2= coeffs(vpa(expand(g(u+hyp(1), v+hyp(2)))));

mattt = [d1(3), d1(2); d2(4), d2(2)]

eig(mattt)


%%


solutions = {csol, csol2, csol3,psol,psol2,psol3};




hold on
for sol = 1:length(solutions)
    
    for i = 1:1000
        
        lambda=solutions{sol}(i,1);
        x=solutions{sol}(i,2);
        y=solutions{sol}(i,3);
        R = 2;
        del = 1/6;
    
        f = (R * x - y) / lambda;
        absf = abs(f);
        sgnf = sign(f);
    
        df_dx = -del - absf - sgnf*R*x / lambda;
        df_dy = sgnf*x / lambda;
    
        dg_dx = -y * sgnf * R / lambda;
        dg_dy = -1 - absf + y * sgnf / lambda;

        mattt = [df_dx, df_dy; dg_dx, dg_dy];
        
        subplot(1,2,1)
        hold on

        if all(eig(mattt)<0) 
            plot(solutions{sol}(i,1), solutions{sol}(i,2),' bo')
        else
            plot(solutions{sol}(i,1), solutions{sol}(i,2), ' ro')
        end

        subplot(1,2,2)
        hold on

        if all(eig(mattt)<0) 
            plot(solutions{sol}(i,1), solutions{sol}(i,3),' bo')
        else
            plot(solutions{sol}(i,1), solutions{sol}(i,3), ' ro')
        end
    end
end

subplot(1,2,1)
xlabel("\lambda")
ylabel("x")
xlim([-0.1 0.7])
ylim([0 0.5])
subplot(1,2,2)
xlabel("\lambda")
ylabel("y")
xlim([-0.1 0.7])
ylim([0 1])
hold off

